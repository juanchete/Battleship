/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Juan
 */
public class BarcoRandom extends Barco{

    byte largo;
    Random rnd = new Random ();
    
    public BarcoRandom(int[] tamano) {
        super(tamano);
    }
    
       Scanner sc = new Scanner (System.in);
    

    
    public void Pc (){
        
        
    }
    
    
}
