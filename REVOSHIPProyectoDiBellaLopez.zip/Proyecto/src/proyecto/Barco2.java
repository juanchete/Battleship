/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

/**
 *
 * @author Juan
 */
public class Barco2 extends Barco {

    public Barco2(int[] tamano) {
        super(tamano);
        
        tamano= new int [2];
        
    }
    
     //SuperPoder Recuperar Vida
     /**public void superVida(int[]vida,int[]barco){
         if(activacion==1){
             System.out.println("Super Poder Activado");
             for (int i = 0; i < barco.length; i++) {
            
         vida[i]=+1;
                 }
             }**/
         
       
}

    
    
    

